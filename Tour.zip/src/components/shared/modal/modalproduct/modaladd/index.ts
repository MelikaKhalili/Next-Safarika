import ModalAddProduct from "./modaladd";

export default ModalAddProduct;
