import Banner2 from "@/assets/images/Banner2.png";
import Image from "next/image";
export default function Secondadvertisingbanner() {
  return (
    <div className="relative w-full aspect-[4/1]">
      <Image src={Banner2} alt="Secondadvertisingbanner" />
    </div>
  );
}
