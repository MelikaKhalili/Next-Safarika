import LandingPageSwiper from "./LandingPageSwiper";

export default LandingPageSwiper;
