// import { RxCross2, RxHamburgerMenu } from "react-icons/rx";
// interface IProps {
//   toggle: () => void;
//   isOpen: boolean;
// }
// export const MenuToggle = ({ toggle, isOpen }: IProps) => (
//   <>
//     <button
//       className=" absolute z-[999] menuToggle !bg-[#0a1f44] flex justify-center items-center"
//       onClick={toggle}
//     >
//       {isOpen ? <RxCross2 size={24} /> : <RxHamburgerMenu size={24} />}
//     </button>
//   </>
// );
