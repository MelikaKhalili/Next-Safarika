import SingleProductSection from "@/components/shop/singleProduct/SingleProduct";

export default function singleProductPage() {
  return (
    <div>
      <SingleProductSection />
    </div>
  );
}
