import ShopSection from "@/components/shop/shop";
import "@splidejs/react-splide/css";

export default function ShopPage() {
  return (
    <div>
      <ShopSection />
    </div>
  );
}
