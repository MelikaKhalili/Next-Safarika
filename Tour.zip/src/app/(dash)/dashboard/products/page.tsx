import ProductsSection from "@/components/dash/products/productsSection";

export default function ProductPage() {
  return (
    <div>
      <ProductsSection />
    </div>
  );
}
