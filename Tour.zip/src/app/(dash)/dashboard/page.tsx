import DashboardHome from "@/components/dash/home/home";

export default function DashBordPage() {
  return (
    <div>
      <DashboardHome />
    </div>
  );
}
