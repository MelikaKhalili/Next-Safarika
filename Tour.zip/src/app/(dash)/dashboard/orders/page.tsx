import OrdersSection from "@/components/dash/orders/orders";

export default function OrdersPage() {
  return (
    <div>
      <OrdersSection />
    </div>
  );
}
