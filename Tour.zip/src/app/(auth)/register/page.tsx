import RegisterForm from "@/components/auth/registerForm/page";
export default function RegisterPage() {
  return (
    <div>
      <RegisterForm />
    </div>
  );
}
