import LoginForm from "@/components/auth/loginForm/page";
export default function LoginPage() {
  return (
    <div>
      <LoginForm />
    </div>
  );
}
