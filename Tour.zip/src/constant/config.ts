export const BASE_URL = "http://api.alikooshesh.ir:3000";
export const API_KEY =
  "melikaShopzWY7AwZPpuzXyocoMsHeRzp6vMEglB4i0leqKr7B5eRO2HBvyrV3KODOdWmMI33mFIBAPlRXbaVog2O158Fr14e8hDDG7IIZZ6BmUXDCq9szX28NbGicbQ";
export const headers = {
  "Content-Type": "application/json",
  api_key: API_KEY,
};
