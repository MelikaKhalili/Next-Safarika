<p align="center">
    <img alt="Gatsby" width="100" src="https://github.com/shahabyazdi/react-multi-date-picker/blob/master/website/src/images/icon.png?raw=true" />
</p>
<h1 align="center">
  Gatsby
</h1>
<h2 align="center">
  DatePicker Demo Page
</h2>

## Quick start

1.  **git clone https://github.com/shahabyazdi/react-multi-date-picker.git**
2.  **cd react-multi-date-picker**
3.  **npm install**
4.  **npm run build**
5.  **cd website**
6.  **npm install**
7.  **gatsby develop**
