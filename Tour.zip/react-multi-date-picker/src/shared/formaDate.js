export default function formatDate(date, format = "YYYY/MM/DD") {
  return date.format(format);
}
