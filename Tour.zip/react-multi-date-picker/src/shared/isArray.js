export default function isArray(array) {
  return Array.isArray(array);
}
