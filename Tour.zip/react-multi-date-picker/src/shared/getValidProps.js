export default function getValidProps({
  state,
  setState,
  position,
  registerListener,
  calendarProps,
  datePickerProps,
  handleChange,
  nodes,
  Calendar,
  DatePicker,
  handlePropsChange,
  handleFocusedDate,
  minDate,
  maxDate,
  ...otherProps
}) {
  return otherProps;
}
